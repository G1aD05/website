# Wind OS
### Description:
Wind OS is a simple os made in python that has many features such as a terminal, creating multiple users, and creating files (File downloading feature coming soon)\
\
So I just found out it works on windows and mac not sure how but it does.
### Features
1. Run an app
2. Make a user
3. Log out
4. New document
5. Open document
6. Move file
7. Terminal
8. Reboot
9. Power Off
10. Settings

##### Version
1.0.0-alpha
